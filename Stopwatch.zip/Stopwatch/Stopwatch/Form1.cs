﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stopwatch
{
    public partial class frmStopWatch : Form
    {
        private short hours, minutes, secound, milliseconds;
        int count = 1;

        public frmStopWatch()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            timer1.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = true;
            timer1.Enabled = false;
        }

        private void incrisemillisecondss()
        {
            if (milliseconds == 99)
            {
                milliseconds = 0;
                incriseSecounds();
            }
            else
            {
                milliseconds++;
            }
        }

        private void incriseSecounds()
        {
            if (secound == 59)
            {
                secound = 0;
                incriseminutess();
            }
            else
            {
                secound++;
            }
        }

        private void incriseminutess()
        {
            if (minutes == 59)
            {
                minutes = 0;
                incriseHours();
            }
            else
            {
                minutes++;
            }
        }

        private void incriseHours()
        {
            hours++;
        }

        private void showTime()
        {
            lblHours.Text = hours.ToString("00");
            lblminutes.Text = minutes.ToString("00");
            lblSecound.Text = secound.ToString("00");
            lblmilliseconds.Text = milliseconds.ToString("00");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            incrisemillisecondss();
            showTime();

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            hours = 0;
            minutes = 0;
            secound = 0;
            milliseconds = 0;

            showTime();
        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            string rHours, rMinutes, rSecounds, rMilliseconds;
            string recordTime;


            rHours = lblHours.Text;
            rMinutes = lblminutes.Text;
            rSecounds = lblSecound.Text;
            rMilliseconds = lblmilliseconds.Text;

            recordTime = count.ToString() + ". " + rHours + ":" + rMinutes + ":" + rSecounds + ":" + rMilliseconds;
            count++;

            richtxtRecord.AppendText(recordTime);
            richtxtRecord.AppendText(Environment.NewLine);

        }

        private void btnClearRecord_Click(object sender, EventArgs e)
        {
            richtxtRecord.Text = "";
            count = 1;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
