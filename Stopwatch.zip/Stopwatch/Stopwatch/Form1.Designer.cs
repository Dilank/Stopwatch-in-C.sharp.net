﻿namespace Stopwatch
{
    partial class frmStopWatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblHours = new System.Windows.Forms.Label();
            this.lblDotOne = new System.Windows.Forms.Label();
            this.lblminutes = new System.Windows.Forms.Label();
            this.lblDotTwo = new System.Windows.Forms.Label();
            this.lblSecound = new System.Windows.Forms.Label();
            this.lblDotThree = new System.Windows.Forms.Label();
            this.lblmilliseconds = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnRecord = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnClearRecord = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.richtxtRecord = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblHours
            // 
            this.lblHours.AutoSize = true;
            this.lblHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHours.Location = new System.Drawing.Point(22, 40);
            this.lblHours.Name = "lblHours";
            this.lblHours.Size = new System.Drawing.Size(64, 44);
            this.lblHours.TabIndex = 0;
            this.lblHours.Text = "00";
            // 
            // lblDotOne
            // 
            this.lblDotOne.AutoSize = true;
            this.lblDotOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDotOne.Location = new System.Drawing.Point(83, 40);
            this.lblDotOne.Name = "lblDotOne";
            this.lblDotOne.Size = new System.Drawing.Size(32, 44);
            this.lblDotOne.TabIndex = 1;
            this.lblDotOne.Text = ":";
            // 
            // lblminutes
            // 
            this.lblminutes.AutoSize = true;
            this.lblminutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutes.Location = new System.Drawing.Point(134, 40);
            this.lblminutes.Name = "lblminutes";
            this.lblminutes.Size = new System.Drawing.Size(64, 44);
            this.lblminutes.TabIndex = 2;
            this.lblminutes.Text = "00";
            // 
            // lblDotTwo
            // 
            this.lblDotTwo.AutoSize = true;
            this.lblDotTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDotTwo.Location = new System.Drawing.Point(210, 40);
            this.lblDotTwo.Name = "lblDotTwo";
            this.lblDotTwo.Size = new System.Drawing.Size(32, 44);
            this.lblDotTwo.TabIndex = 3;
            this.lblDotTwo.Text = ":";
            // 
            // lblSecound
            // 
            this.lblSecound.AutoSize = true;
            this.lblSecound.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecound.Location = new System.Drawing.Point(261, 40);
            this.lblSecound.Name = "lblSecound";
            this.lblSecound.Size = new System.Drawing.Size(64, 44);
            this.lblSecound.TabIndex = 4;
            this.lblSecound.Text = "00";
            // 
            // lblDotThree
            // 
            this.lblDotThree.AutoSize = true;
            this.lblDotThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDotThree.Location = new System.Drawing.Point(333, 40);
            this.lblDotThree.Name = "lblDotThree";
            this.lblDotThree.Size = new System.Drawing.Size(32, 44);
            this.lblDotThree.TabIndex = 5;
            this.lblDotThree.Text = ":";
            // 
            // lblmilliseconds
            // 
            this.lblmilliseconds.AutoSize = true;
            this.lblmilliseconds.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmilliseconds.Location = new System.Drawing.Point(377, 40);
            this.lblmilliseconds.Name = "lblmilliseconds";
            this.lblmilliseconds.Size = new System.Drawing.Size(64, 44);
            this.lblmilliseconds.TabIndex = 6;
            this.lblmilliseconds.Text = "00";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(40, 116);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 7;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnRecord
            // 
            this.btnRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecord.Location = new System.Drawing.Point(153, 116);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(75, 23);
            this.btnRecord.TabIndex = 8;
            this.btnRecord.Text = "Record";
            this.btnRecord.UseVisualStyleBackColor = true;
            this.btnRecord.Click += new System.EventHandler(this.btnRecord_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(269, 116);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 9;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.Location = new System.Drawing.Point(366, 116);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 10;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnClearRecord
            // 
            this.btnClearRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearRecord.Location = new System.Drawing.Point(248, 169);
            this.btnClearRecord.Name = "btnClearRecord";
            this.btnClearRecord.Size = new System.Drawing.Size(96, 23);
            this.btnClearRecord.TabIndex = 11;
            this.btnClearRecord.Text = "Clear Records";
            this.btnClearRecord.UseVisualStyleBackColor = true;
            this.btnClearRecord.Click += new System.EventHandler(this.btnClearRecord_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(366, 169);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(470, 31);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(82, 20);
            this.lblTitle.TabIndex = 14;
            this.lblTitle.Text = "Lap Time";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // richtxtRecord
            // 
            this.richtxtRecord.Location = new System.Drawing.Point(474, 61);
            this.richtxtRecord.Name = "richtxtRecord";
            this.richtxtRecord.Size = new System.Drawing.Size(170, 175);
            this.richtxtRecord.TabIndex = 15;
            this.richtxtRecord.Text = "";
            // 
            // frmStopWatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 260);
            this.Controls.Add(this.richtxtRecord);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClearRecord);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnRecord);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblmilliseconds);
            this.Controls.Add(this.lblDotThree);
            this.Controls.Add(this.lblSecound);
            this.Controls.Add(this.lblDotTwo);
            this.Controls.Add(this.lblminutes);
            this.Controls.Add(this.lblDotOne);
            this.Controls.Add(this.lblHours);
            this.Name = "frmStopWatch";
            this.Text = "StopWatch";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHours;
        private System.Windows.Forms.Label lblDotOne;
        private System.Windows.Forms.Label lblminutes;
        private System.Windows.Forms.Label lblDotTwo;
        private System.Windows.Forms.Label lblSecound;
        private System.Windows.Forms.Label lblDotThree;
        private System.Windows.Forms.Label lblmilliseconds;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnClearRecord;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RichTextBox richtxtRecord;
    }
}

